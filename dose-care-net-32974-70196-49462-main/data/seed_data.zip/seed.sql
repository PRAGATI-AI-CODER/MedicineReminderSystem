-- seed.sql
-- Auto-generated seed for Delhi NCR + Dehradun dataset
SET client_encoding = 'UTF8';
BEGIN;

CREATE TABLE IF NOT EXISTS hospital (
  hospital_id VARCHAR PRIMARY KEY,
  name TEXT,
  city TEXT,
  state TEXT,
  pin VARCHAR,
  contact VARCHAR,
  type VARCHAR,
  address TEXT,
  lat DOUBLE PRECISION,
  lon DOUBLE PRECISION
);

CREATE TABLE IF NOT EXISTS medication (
  med_id VARCHAR PRIMARY KEY,
  brand_name TEXT,
  generic_name TEXT,
  dosage TEXT,
  unit VARCHAR,
  mrp NUMERIC,
  manufacturer TEXT
);

CREATE TABLE IF NOT EXISTS patient (
  patient_id VARCHAR PRIMARY KEY,
  name TEXT,
  gender VARCHAR,
  age INTEGER,
  city TEXT,
  phone VARCHAR,
  hospital_id VARCHAR REFERENCES hospital(hospital_id),
  consent_sms BOOLEAN,
  consent_whatsapp BOOLEAN,
  consent_push BOOLEAN
);

CREATE TABLE IF NOT EXISTS inventory (
  inv_id VARCHAR PRIMARY KEY,
  hospital_id VARCHAR REFERENCES hospital(hospital_id),
  med_id VARCHAR REFERENCES medication(med_id),
  batch_no VARCHAR,
  qty INTEGER,
  expiry_date DATE
);

-- Import CSVs (adjust path if needed)
\copy hospital(hospital_id,name,city,state,pin,contact,type,address,lat,lon) FROM '/mnt/data/delhi_ncr_dehradun_seed/hospital.csv' CSV HEADER;
\copy medication(med_id,brand_name,generic_name,dosage,unit,mrp,manufacturer) FROM '/mnt/data/delhi_ncr_dehradun_seed/medication.csv' CSV HEADER;
\copy patient(patient_id,name,gender,age,city,phone,hospital_id,consent_sms,consent_whatsapp,consent_push) FROM '/mnt/data/delhi_ncr_dehradun_seed/patient.csv' CSV HEADER;
\copy inventory(inv_id,hospital_id,med_id,batch_no,qty,expiry_date) FROM '/mnt/data/delhi_ncr_dehradun_seed/inventory.csv' CSV HEADER;

COMMIT;
