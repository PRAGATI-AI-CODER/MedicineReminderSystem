
Delhi NCR + Dehradun Seed Data
Files in this package:
- hospital.csv (60 records)
- medication.csv (50 records)
- patient.csv (70 records)
- inventory.csv (120 records)
- seed.sql (creates tables and uses \copy to import CSVs)
Notes:
- CSV files are UTF-8 encoded.
- seed.sql uses psql-compatible \copy commands; if using psql, run: psql -d yourdb -f seed.sql
- If your DB server is remote, copy CSVs to the server and adjust paths in seed.sql accordingly.
- All IDs are prefixed (H, M, P, I) for clarity and FK consistency.
